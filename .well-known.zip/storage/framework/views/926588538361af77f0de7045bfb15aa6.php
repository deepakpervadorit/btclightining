<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <?php echo $__env->yieldContent('style'); ?>

</head>
<body>
    <div id="app">
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-primary">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Cumbo</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav m-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Link</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Dropdown
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                            </li>
                        </ul>
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <a class="btn btn-warning btn-sm" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            <?php endif; ?>
                            
                        <?php endif; ?>
                    </div>
                </div>
            </nav>
        </header>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer>
            <div class="container-fluid">
                <div class="px-lg-3">
                    <div class="row mx-0">
                        <div class="col">
                            <h4 class="fs-2"><a class="nav-link" href="<?php echo e(url('/')); ?>">Cumbo</a></h4>
                        </div>
                        <div class="col">
                            <h4>Hosting</h4>
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link ps-0 active" aria-current="page" href="#">VPS Hosting</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="#">Dedicated Business Hosting</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="#">Prepaid Hosting</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col">
                            <h4>Company</h4>
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="#">Pricing</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="#">FAQs</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="#">About Us</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col">
                            <h4>Get Help</h4>
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="#">Contact Us</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="#">Privacy policy</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="#">T & C Apply</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col">
                            <h4>Contact</h4>
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link ps-0" href="mailto:support@cumbo.com">support@cumbo.com</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- Bootstrap 5 JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Include jQuery for simplicity -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH /home/cumbotech123/pay.cumbo.tech/resources/views/layouts/userapp.blade.php ENDPATH**/ ?>