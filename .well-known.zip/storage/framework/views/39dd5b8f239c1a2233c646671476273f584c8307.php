

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2>Dashboard</h2>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Deposits</h5>
                <input class="form-control" type="text" value="https://pay.kumeo.com/ksweeps/deposit" readonly>
                <button class="btn btn-primary mt-2">Copy</button>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Withdrawals</h5>
                <input class="form-control" type="text" value="https://pay.kumeo.com/ksweeps/withdraw" readonly>
                <button class="btn btn-primary mt-2">Copy</button>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Overall Statistics</h5>
                <div class="row">
                    <div class="col-md-3">
                        <p>Total Deposits: <span class="text-success">$4,964.00</span></p>
                    </div>
                    <div class="col-md-3">
                        <p>Total Withdrawals: <span class="text-danger">$0.00</span></p>
                    </div>
                    <div class="col-md-3">
                        <p>Fees Owed: <span class="text-danger">$0.00</span></p>
                    </div>
                    <div class="col-md-3">
                        <p>Cash Flow: <span class="text-success">$4,964.00</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">
                <!-- Include your chart here -->
                <canvas id="dashboardChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Stats Section (8 columns) -->
<div class="row">
    <!-- Deposit Total -->
    <div class="col-md-6">
        <div class="card text-white bg-primary mb-4">
            <div class="card-body">
                <h5 class="card-title">Deposit Total</h5>
                <p class="card-text">$</p>
            </div>
        </div>
    </div>
    
    <!-- Withdrawal Total -->
    <div class="col-md-6">
        <div class="card text-white bg-warning mb-4">
            <div class="card-body">
                <h5 class="card-title">Withdrawal Total</h5>
                <p class="card-text"></p>
            </div>
        </div>
    </div>

    <!-- Deposit Average -->
    <div class="col-md-6">
        <div class="card text-white bg-primary mb-4">
            <div class="card-body">
                <h5 class="card-title">Deposit Avg</h5>
                <p class="card-text">$</p>
            </div>
        </div>
    </div>
    
    <!-- Withdrawal Average -->
    <div class="col-md-6">
        <div class="card text-white bg-warning mb-4">
            <div class="card-body">
                <h5 class="card-title">Withdrawal Avg</h5>
                <p class="card-text"></p>
            </div>
        </div>
    </div>
    
    <!-- Deposit Count -->
    <div class="col-md-6">
        <div class="card text-white bg-primary mb-4">
            <div class="card-body">
                <h5 class="card-title">Deposit Count Total</h5>
                <p class="card-text"></p>
            </div>
        </div>
    </div>
    
        <!-- Withdrawal Count -->
    <div class="col-md-6">
        <div class="card text-white bg-warning mb-4">
            <div class="card-body">
                <h5 class="card-title">Withdrawal Count Total</h5>
                <p class="card-text"></p>
            </div>
        </div>
    </div>


    <!-- Top Depositing Player -->
    <div class="col-md-6">
        <div class="card text-white bg-primary mb-4">
            <div class="card-body">
                <h5 class="card-title">Top Depositing Player</h5>
                <p class="card-text"></p>
            </div>
        </div>
    </div>

    

    


    <!-- Top Withdrawing Player -->
    <div class="col-md-6">
        <div class="card text-white bg-warning mb-4">
            <div class="card-body">
                <h5 class="card-title">Top Withdrawing Player</h5>
                <p class="card-text"></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
  var ctx = document.getElementById('dashboardChart').getContext('2d');
    var dashboardChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($chartLabels); ?>,
            datasets: [{
                label: 'Deposits',
                data: <?php echo json_encode($chartData); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cumboqbo/pay.cumbo.tech/resources/views/dashboard.blade.php ENDPATH**/ ?>