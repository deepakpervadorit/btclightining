

<?php $__env->startSection('content'); ?>
    <style>
       nav.navbar.navbar-expand-lg.navbar-light.bg-primary {
    display: none;
}
footer {
    display: none;
}
nav.navbar.navbar-expand-lg.navbar-light.bg-white {
    display: none;
}
hr.my-0 {
    display: none;
}
        #loader {
            display: none;
        }
        button#card-button {
    text-align: center;
    display: block;
    width: 50%;
    margin: auto;
    margin-bottom: 20px;
}
    </style>
    <section class="bg-light">
        <div class="container">
            <div class="row justify-content-center align-items-center min-vh-100">
                <div class="col-xl-5 col-lg-6 col-md-8 col-sm-10">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="alert alert-warning border-0 border-start border-5 border-warning rounded-0" role="alert">
                                <h3 class="fs-6">Your Deposit Link</h3>
                                <?php if($paymentMethod == 'stripe'): ?>
                                    <p>Click below on pay to complete your deposit:</p>
                                    <div class="d-flex mt-3">
                                        <form id="deposit-form" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="server" id="server" value="<?php echo e($server); ?>">
                                            <input type="hidden" name="paymentMethod" value="Stripe">
                                            <input type="hidden" name="username" id="username" value="<?php echo e($username); ?>">
                                            <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                            <button type="submit" class="btn btn-warning btn-sm" id="checkout-button">Pay Now</button>
                                        </form>
                                        <a href="<?php echo e(route('show.deposit.form')); ?>" class="btn btn-light-warning btn-sm">New Deposit</a>
                                    </div>
                                <?php elseif($paymentMethod == 'squareup'): ?>
                                    <p>Click below on pay after select payment type to complete your deposit:</p>
                                    <form id="payment-form" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="server" id="server" value="<?php echo e($server); ?>">
                                        <input type="hidden" name="paymentMethod" value="Square">
                                        <input type="hidden" name="username" id="username" value="<?php echo e($username); ?>">
                                        <input type="hidden" name="amount" id="amount" value="<?php echo e($amount); ?>">
                                        <input type="hidden" id="payment-method" value="card">
                                        <!--<div class="mb-3 w-100" id="payment-type">-->
                                        <!--    <label class="form-label" for="payment-method">Payment Type</label>-->
                                        <!--    <select class="form-select" id="payment-method">-->
                                        <!--        <option value="card">Debit Card</option>-->
                                        <!--        <option value="cash-app">Cash App</option>-->
                                        <!--        <option value="apple-pay">Apple Pay</option>-->
                                        <!--    </select>-->
                                        <!--</div>-->
                                        <div class="d-flex mb-3">
                                            <button type="submit" class="btn btn-warning btn-sm" id="payment-button">Pay Now</button>
                                            <a href="<?php echo e(route('show.deposit.form')); ?>" class="btn btn-light-warning btn-sm">New Deposit</a>
                                        </div>
                                    </form>
                                    
                                    <div id="loader" class="spinner-border text-primary" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <div id="card-container"></div>
                                    <button type="button" class="btn btn-warning btn-sm" id="card-button" style="display: none;">Pay With Card</button>
                                    <span id="or" style="display:none; text-align:center;">OR</span>
                                    <br>
                                    <div id="cash-app-pay"></div>
                                    <div id="apple-pay-button"></div>
                                    <div id="token-display"></div>
                                
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://js.squareup.com/v2/paymentform"></script>
    <script src="https://web.squarecdn.com/v1/square.js"></script>
    <script type="text/javascript" src="https://sandbox.web.squarecdn.com/v1/square.js"></script>
    <script type="text/javascript" src="https://web.squarecdn.com/v1/square.js"></script>


    <script>
    var base_url = "<?php echo e(url('/')); ?>";
    let card;
    

    // Function to send payment data to the server
    async function get_data(amount, payment_method, token) {
        var username = document.getElementById('username').value;
    var server = document.getElementById('server').value;
        const res = await fetch("<?php echo e(route('square.process.deposit', ['id' => $uniqueId])); ?>", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            body: JSON.stringify({
                
                amount: amount,
                payment_method: payment_method,
                token: token,
                username: username,
                server:server,
            })
        });
        const data = await res.json();
        console.log(data);
        // Optionally handle successful payment completion
    }
    // Function to initialize payment options
    async function initializePayment(amount, payment_method) {
        try {
            document.getElementById('loader').style.display = 'block';
            document.getElementById('payment-button').style.display = 'none';

const payments = Square.payments('sandbox-sq0idb-Fx0L1iWORofVKMEKpjX4bg', 'sandbox');
            const paymentRequest = payments.paymentRequest({
                countryCode: 'US',
                currencyCode: 'USD',
                total: {
                    amount: amount.toFixed(2),
                    label: 'Total',
                },
            });

            const options = {
                redirectURL: window.location.href,
                referenceId: 'my-distinct-reference-id',
            };

            // Handling Cash App Payment
            if (payment_method === 'cash-app') {
                

            // Handling Apple Pay Payment
            } else if (payment_method === 'apple-pay') {
                

            // Handling Card Payment
            } else if (payment_method === 'card') {
               // Initialize card globally
card = await payments.card(); 
await card.attach('#card-container'); // Attach the card input form to the container

document.getElementById('card-container').style.display = 'block';
document.getElementById('card-button').textContent = `Pay $${amount}`;
document.getElementById('card-button').style.display = 'block';

const cashAppPay = await payments.cashAppPay(paymentRequest, options);
cashAppPay.addEventListener('ontokenization', (event) => {
    const { tokenResult } = event.detail;
    if (tokenResult.status === 'OK') {
        // Get hidden input values
        const server = document.getElementById('server').value;
        const paymentMethod = 'Square Debit-Card';
        const username = document.getElementById('username').value;
        const paymentAmount = document.getElementById('amount').value;
        // Send all data to get_data function
        get_data(paymentAmount, paymentMethod, tokenResult.token, username, server, paymentMethodId);
    } else {
        console.error(tokenResult);
    }
});

                document.getElementById('cash-app-pay').style.display = 'block';
                await cashAppPay.attach('#cash-app-pay', { shape: 'semiround', width: 'full' });
                
                // const applePay = await payments.applePay(paymentRequest, options);
                // applePay.addEventListener('ontokenization', (event) => {
                //     const { tokenResult } = event.detail;
                //     if (tokenResult.status === 'OK') {
                //         get_data(amount, payment_method, tokenResult.token);
                //     } else {
                //         console.error(tokenResult);
                //     }
                // });
                // document.getElementById('apple-pay-button').style.display = 'block';
                // await applePay.attach('#apple-pay-button', { shape: 'semiround', width: 'full' });
            }

            document.getElementById('loader').style.display = 'none';
        } catch (error) {
            console.error('Error initializing payment:', error);
        }
    }

    // Handling Form Submit for Square Payment
    document.getElementById('payment-form').addEventListener('submit', (event) => {
        event.preventDefault();
        const amount = parseFloat(document.getElementById('amount').value) + 0.09;
        const payment_method = document.getElementById('payment-method').value;
        initializePayment(amount, payment_method);
    });

    // Handling Card Payment Submit Button
    document.getElementById('card-button').addEventListener('click', async (event) => {
        event.preventDefault();
        const amount = parseFloat(document.getElementById('amount').value) + 0.09;
        const payment_method = 'card';

        try {
            if (!card) {
                throw new Error('Card payment method not initialized'); // Ensure card is initialized
            }

            const result = await card.tokenize(); // Tokenize the card
            if (result.status === 'OK') {
                get_data(amount, payment_method, result.token); // Process the payment
                alert('Payment completed and data inserted successfully!');
                
            } else {
                console.error(result.errors);
            }
        } catch (error) {
            console.error('Error during card payment:', error);
        }
    });
</script>

<script>
    // jQuery to handle Stripe Payment Form
    $(document).ready(function() {
        $('#deposit-form').on('submit', function(event) {
            event.preventDefault(); // Prevent the form from submitting normally

            // Serialize the form data
            var formData = $(this).serialize();

            // Perform AJAX request to process the deposit via Stripe
            $.ajax({
                url: "<?php echo e(route('process.deposit', ['id' => $uniqueId])); ?>", // Laravel route for processing
                method: 'POST',
                data: formData, // Send serialized form data
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') // Ensure CSRF token is sent
                },
                success: function(response) {
                    // Redirect to Stripe's checkout page
                    if (response.url) {
                        window.location.href = response.url;
                    } else {
                        alert('Failed to create Stripe session');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    alert('There was an error processing the payment. Please try again.');
                }
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cumbotech123/pay.cumbo.tech/resources/views/deposit-link.blade.php ENDPATH**/ ?>