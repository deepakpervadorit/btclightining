

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1 class="mb-4">Create New Role</h1>

    <div class="card">
        <div class="card-header">
            <h5>Create New Role</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('roles.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Role Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="permissions" class="form-label">Assign Permissions</label>
                    <div>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input type="checkbox" name="permissions[]" class="form-check-input" value="<?php echo e($permission->id); ?>">
                                <label class="form-check-label"><?php echo e($permission->name); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <button type="submit" class="btn btn-success">Create Role</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cumbotech123/pay.cumbo.tech/resources/views/admin/roles/create.blade.php ENDPATH**/ ?>