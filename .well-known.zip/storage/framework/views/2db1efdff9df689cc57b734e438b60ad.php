<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Link</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<section class="bg-light">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-xl-5 col-lg-6 col-md-8 col-sm-10">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <div class="alert alert-warning border-0 border-start border-5 border-warning rounded-0" role="alert">
                            <h3 class="fs-6">Your Deposit Link</h3>
                            <p>Click the link below to complete your deposit:</p>
                            <a href="<?php echo e(route('process.deposit', ['id' => $uniqueId])); ?>" class="link-warning"><?php echo e(route('process.deposit', ['id' => $uniqueId])); ?></a>
                            <div class="d-flex mt-3">
                                <form id="deposit-form" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <button type="submit" class="btn btn-warning btn-sm" id="checkout-button">Pay Now</button>
                                </form>
                                <a href="<?php echo e(route('show.deposit.form')); ?>" class="btn btn-light-warning btn-sm">New Deposit</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<!-- Include jQuery for simplicity -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function() {
        $('#deposit-form').on('submit', function(event) {
            event.preventDefault(); // Prevent the form from submitting normally

            // Serialize the form data
            var formData = $(this).serialize();

            // Perform AJAX request to process the deposit
            $.ajax({
                url: "<?php echo e(route('process.deposit', ['id' => $uniqueId])); ?>", // Laravel route for processing
                method: 'POST',
                data: formData, // Send serialized form data
                success: function(response) {
                    if (response.url) {
                        // Redirect to Stripe's checkout page
                        window.location.href = response.url;
                    } else {
                        alert('Failed to create Stripe session');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    alert('There was an error processing the payment. Please try again.');
                }
            });
        });
    });
</script>
</body>
</html><?php /**PATH D:\360 projects\stripe-laravel\resources\views/deposit-link.blade.php ENDPATH**/ ?>