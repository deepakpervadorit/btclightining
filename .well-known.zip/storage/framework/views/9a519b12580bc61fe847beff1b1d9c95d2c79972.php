<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ksweeps - <?php echo $__env->yieldContent('title'); ?></title> <!-- Dynamic page title -->
    <!-- Add Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#f3f4f6">
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="#">Ksweeps</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('deposit')); ?>">Deposit</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('withdrawal')); ?>">Withdrawal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('staff')); ?>">Staff</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('disputes')); ?>">Disputes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('service_provider')); ?>">Service Provider</a>
                    </li>
                </ul>
            </div>
            <div class="d-flex">
                <span class="nav-item">Admin</span>
                <span class="nav-item">K</span>
            </div>
        </div>
    </nav>
    <hr class="my-0" style="border-color: #f3f4f6;
    opacity: 1;">
    <!-- Breadcrumb section -->
    <div class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <h5><?php echo $__env->yieldContent('breadcrumb'); ?></h5> <!-- Breadcrumb will be updated dynamically -->
        </div>
    </div>

    <div class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Add Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH /home/cumboqbo/pay.cumbo.tech/resources/views/layouts/app.blade.php ENDPATH**/ ?>