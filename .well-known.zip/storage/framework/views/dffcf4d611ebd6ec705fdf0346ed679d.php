

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col">
        <h2>Dashboard</h2>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
           <div class="card-body">
                <h5 class="card-title">Deposits</h5>
                <input class="form-control" type="text" value="<?php echo e(route('show.deposit.form')); ?>" id="depositLink" readonly>
                <button class="btn btn-primary mt-2" onclick="copyToClipboard('depositLink')">Copy</button>
           </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Withdrawals</h5>
                <input class="form-control" type="text" value="https://pay.kumeo.com/ksweeps/withdraw" id="withdrawalLink" readonly>
                <button class="btn btn-primary mt-2" onclick="copyToClipboard('withdrawalLink')">Copy</button>
            </div>
        </div>
    </div>
</div>

<!--<div class="row mt-4">-->
<!--    <div class="col-lg-12">-->
<!--        <div class="card">-->
<!--            <div class="card-body">-->
<!--                <h5 class="card-title">Overall Statistics</h5>-->
<!--                <div class="row">-->
<!--                    <div class="row g-3">-->
                        <!-- Total Deposits -->
<!--                        <div class="col-12 col-sm-6 col-md-4 col-lg-2" style="width:20% !important;">-->
<!--                            <div class="card shadow-sm">-->
<!--                                <div class="card-body">-->
<!--                                    <h6 class="text-muted">Total Deposits</h6>-->
<!--                                    <div class="d-flex align-items-center">-->
<!--                                        <h3 class="text-success">$<?php echo e($totalDeposit); ?></h3>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                        </div>-->

                        <!-- Total Withdrawals -->
<!--                        <div class="col-12 col-sm-6 col-md-4 col-lg-2" style="width:20% !important;">-->
<!--                            <div class="card shadow-sm">-->
<!--                                <div class="card-body">-->
<!--                                    <h6 class="text-muted">Total Withdrawals</h6>-->
<!--                                    <div class="d-flex align-items-center">-->
<!--                                        <h3 class="text-danger">$220.00</h3>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                        </div>-->

                        <!-- Fees Owed -->
<!--                        <div class="col-12 col-sm-6 col-md-4 col-lg-2" style="width:20% !important;">-->
<!--                            <div class="card shadow-sm">-->
<!--                                <div class="card-body">-->
<!--                                    <h6 class="text-muted">Fees Owed</h6>-->
<!--                                    <div class="d-flex align-items-center">-->
<!--                                        <h3 class="text-danger">$0.00</h3>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                        </div>-->

                        <!-- Disputes -->
<!--                        <div class="col-12 col-sm-6 col-md-4 col-lg-2" style="width:20% !important;">-->
<!--                            <div class="card shadow-sm">-->
<!--                                <div class="card-body">-->
<!--                                    <h6 class="text-muted">Disputes</h6>-->
<!--                                    <div class="d-flex align-items-center">-->
<!--                                        <h3 class="text-danger">$0.00</h3>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                        </div>-->

                        <!-- Cash Flow -->
<!--                        <div class="col-12 col-sm-6 col-md-4 col-lg-2" style="width:20% !important;">-->
<!--                            <div class="card shadow-sm">-->
<!--                                <div class="card-body">-->
<!--                                    <h6 class="text-muted">Cash Flow</h6>-->
<!--                                    <div class="d-flex align-items-center">-->
<!--                                        <h3 class="text-success">$6,216.00</h3>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->

<div class="row">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">
<canvas id="dashboardChart"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="d-md-flex">
    <div class="mx-auto bg-white w-100 mt-4">
        <div>
            <div class="pb-4 px-4 py-md-4">
                <div>
                    <dl class="mt-5 row row-cols-1 g-3">
                        <div class="overflow-hidden rounded bg-white shadow" style="background: linear-gradient(to left, #90CDF4, #3182CE); padding: 1.5rem;">
                            <dt class="text-white text-truncate text-sm fw-medium">Deposit Total</dt>
                            <div class="d-flex">
                                <div class="d-flex align-items-center">
                                    <dd class="mt-1 display-6 fw-semibold text-white">$<?php echo e($totalDeposit); ?></dd>
                                </div>
                                <div class="d-flex align-items-center ms-auto"></div>
                            </div>
                        </div>
                        <div class="overflow-hidden rounded bg-white shadow" style="background: linear-gradient(to left, #90CDF4, #3182CE); padding: 1.5rem;">
                            <dt class="text-white text-truncate text-sm fw-medium">Deposit Avg</dt>
                            <div class="d-flex">
                                <div class="d-flex align-items-center">
                                    <dd class="mt-1 display-6 fw-semibold text-white">$<?php echo e($avgDeposit); ?></dd>
                                </div>
                                <div class="d-flex align-items-center ms-auto"></div>
                            </div>
                        </div>
                        <div class="overflow-hidden rounded bg-white shadow" style="background: linear-gradient(to left, #90CDF4, #3182CE); padding: 1.5rem;">
                            <dt class="text-white text-truncate text-sm fw-medium">Deposit Count Total</dt>
                            <div class="d-flex">
                                <div class="d-flex align-items-center">
                                    <dd class="mt-1 display-6 fw-semibold text-white"><?php echo e($countDeposit); ?></dd>
                                </div>
                                <div class="d-flex align-items-center ms-auto"></div>
                            </div>
                        </div>
                        <div class="overflow-hidden rounded bg-white shadow" style="background: linear-gradient(to left, #90CDF4, #3182CE); padding: 1.5rem;">
                            <dt class="text-white text-truncate text-sm fw-medium">Top Depositing Player</dt>
                            <div class="d-flex">
                                <div class="d-flex align-items-center">
                                    <dd class="mt-1 display-6 fw-semibold text-white"><?php echo e($topDepositor->username); ?></dd>
                                </div>
                                <div class="d-flex align-items-center ms-auto"></div>
                            </div>
                        </div>
                    </dl>
                </div>
            </div>
        </div>
    </div>
    <div class="mx-auto bg-white w-100 mt-4">
        <div>
            <div class="pb-4 px-4 py-md-4">
                <div>
                    <dl class="mt-5 row row-cols-1 g-3">
                        <div class="overflow-hidden rounded bg-white shadow" style="background: linear-gradient(to left, #F6AD55, #DD6B20); padding: 1.5rem;">
                            <dt class="text-white text-truncate text-sm fw-medium">Withdrawal Total</dt>
                            <div class="d-flex">
                                <div class="d-flex align-items-center">
                                    <dd class="mt-1 display-6 fw-semibold text-white">$220.00</dd>
                                </div>
                                <div class="d-flex align-items-center ms-auto"></div>
                            </div>
                        </div>
                        <div class="overflow-hidden rounded bg-white shadow" style="background: linear-gradient(to left, #F6AD55, #DD6B20); padding: 1.5rem;">
                            <dt class="text-white text-truncate text-sm fw-medium">Withdrawal Avg</dt>
                            <div class="d-flex">
                                <div class="d-flex align-items-center">
                                    <dd class="mt-1 display-6 fw-semibold text-white">$73.33</dd>
                                </div>
                                <div class="d-flex align-items-center ms-auto"></div>
                            </div>
                        </div>
                        <div class="overflow-hidden rounded bg-white shadow" style="background: linear-gradient(to left, #F6AD55, #DD6B20); padding: 1.5rem;">
                            <dt class="text-white text-truncate text-sm fw-medium">Withdrawal Count Total</dt>
                            <div class="d-flex">
                                <div class="d-flex align-items-center">
                                    <dd class="mt-1 display-6 fw-semibold text-white">3</dd>
                                </div>
                                <div class="d-flex align-items-center ms-auto"></div>
                            </div>
                        </div>
                        <div class="overflow-hidden rounded bg-white shadow" style="background: linear-gradient(to left, #F6AD55, #DD6B20); padding: 1.5rem;">
                            <dt class="text-white text-truncate text-sm fw-medium">Top Withdrawing Player</dt>
                            <div class="d-flex">
                                <div class="d-flex align-items-center">
                                    <dd class="mt-1 display-6 fw-semibold text-white">M-111-716-880 Golden Dragon</dd>
                                </div>
                                <div class="d-flex align-items-center ms-auto"></div>
                            </div>
                        </div>
                    </dl>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var chartElement = document.getElementById('dashboardChart');

    if (chartElement) {
        var ctx = chartElement.getContext('2d');
        var dashboardChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($chartLabels); ?>, // Week labels
                datasets: [
                    {
                        label: 'Deposits',
                        data: <?php echo json_encode($depositData); ?>, // Deposit data for each week
                        backgroundColor: 'rgba(54, 162, 235, 0.6)', // Light blue
                        borderColor: 'rgba(54, 162, 235, 1)', // Darker blue for borders
                        borderWidth: 1
                    },
                    {
                        label: 'Withdrawals',
                        data: <?php echo json_encode($withdrawData); ?>, // Withdrawal data for each week
                        backgroundColor: 'rgba(255, 99, 132, 0.6)', // Light red
                        borderColor: 'rgba(255, 99, 132, 1)', // Darker red for borders
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true // Start the y-axis from 0
                    }
                }
            }
        });
    } else {
        console.error('Canvas element with id "dashboardChart" not found');
    }
</script>

<script>

  function copyToClipboard(elementId) {
      const copyText = document.getElementById(elementId);
      if (navigator.clipboard) {
          navigator.clipboard.writeText(copyText.value)
              .then(() => alert('Link copied to clipboard!'))
              .catch(err => console.error('Failed to copy: ', err));
      } else {
          copyText.select();
          document.execCommand("copy");
          alert("Link copied to clipboard!");
      }
  }
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cumbotech123/pay.cumbo.tech/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>