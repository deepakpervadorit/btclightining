

<?php $__env->startSection('content'); ?>
    <section class="bg-light">
        <div class="container">
            <div class="row justify-content-center align-items-center min-vh-100">
                <div class="col-xl-5 col-lg-6 col-md-8 col-sm-10">
                    <div class="card border-0 shadow">
                        <div class="card-body text-center">
                            <!-- Display the success message -->
                            <h3 class="fs-4">Thank You!</h3>
                            <?php if(session('message')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>
                            <a href="<?php echo e(url('/')); ?>" class="btn btn-warning">Go to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cumbotech123/pay.cumbo.tech/resources/views/thank-you.blade.php ENDPATH**/ ?>