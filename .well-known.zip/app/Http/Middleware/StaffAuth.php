<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class StaffAuth
{
    public function handle(Request $request, Closure $next, $role = null)
    {
        // Check if staff is logged in via session
        if (!Session::has('staff_id')) {
            return redirect()->route('login')->withErrors('You must be logged in to access this page.');
        }

        // Get the logged-in staff ID from the session
        $staffId = Session::get('staff_id');

        // If a specific role is required, check if the user has the role
        if ($role) {
            // Fetch the user's roles from the `role_staff` pivot table
            $userRoles = DB::table('roles')
                            ->join('role_staff', 'roles.id', '=', 'role_staff.role_id')
                            ->where('role_staff.staff_id', $staffId)
                            ->pluck('roles.name')
                            ->toArray();

            // Check if the user's roles include the required role
            if (!in_array($role, $userRoles)) {
                return redirect()->route('login')->withErrors('You do not have permission to access this page.');
            }
        }

        // Allow the request to proceed if all checks pass
        return $next($request);
    }

}
