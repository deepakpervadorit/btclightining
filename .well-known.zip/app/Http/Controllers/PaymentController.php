<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe\Stripe;
use Stripe\Checkout\Session as CheckoutSession;
use Stripe\Price;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Square\Models\Money;
use Square\Models\CreatePaymentRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Http;
use Square\SquareClient;
use Square\Models\CreatePaymentLinkRequest;
use Square\Exceptions\ApiException;


class PaymentController extends Controller
{
        public function payments()
    {
        $deposits = DB::table('deposits')->get();
        return view('admin.payments', compact('deposits'));
    }
    
    public function showForm()
    {
        $games = DB::table('games')->get();
        return view('deposit',compact('games'));
    }

    public function depositLink(Request $request)
    {
        
        // echo "<pre>";
        // print_r($request->toArray());
        // exit;
        // Extract the inputs
        $server = $request->input('server');
        $paymentMethod = $request->input('payment_method');
        $username = $request->input('username');
        $amount = $request->input('amount');

        // Generate a unique
        $uniqueId = Str::random(10);
        // DB::table('deposits')->insert([
        //     'unique_id' => $uniqueId,
        //     'server' => $server,
        //     'payment_method' => $paymentMethod,
        //     'username' => $username,
        //     'amount' => $amount,
        //     'created_at' => now(),
        //     'updated_at' => now(),
        // ]);
        // Option 1: Redirect to the deposit link directly
        return view('deposit-link', compact('server', 'paymentMethod', 'username', 'amount', 'uniqueId'));
    }

    public function processDeposit(Request $request)
{
    $stripeSecretKey = env('STRIPE_SECRET');
    \Stripe\Stripe::setApiKey($stripeSecretKey);

    // Get the amount from the request
    $amount = $request->input('amount') + 0.09;

    try {
        // Create a new Price object in Stripe for the specified amount
        $price = \Stripe\Price::create([
            'unit_amount' => $amount * 100, // Amount in cents
            'currency' => 'usd', // Set your desired currency
            'nickname' => 'Deposit Amount',
            'product_data' => [
                'name' => 'Customer Deposit',
            ],
        ]);

        // Create a new Checkout session using the created Price ID
        $checkoutSession = \Stripe\Checkout\Session::create([
            'line_items' => [[
                'price' => $price->id, // Use the created price ID
                'quantity' => 1,
            ]],
            'mode' => 'payment', // Payment mode for one-time charges
            'success_url' => route('deposit.stripe.success'),
            'cancel_url' => route('show.deposit.form'),
        ]);
        $sessionId = $checkoutSession->id;
        Session::put('stripe_session', $sessionId);
        // Save deposit details in the database
        DB::table('deposits')->insert([
            'status' => 'Paid', // Initial status, will update after payment confirmation
            'payment_method' => 'Stripe',
            'amount' => $request->input('amount'),
            'username' => $request->input('username'),
            'server' => $request->input('server'),
            'sessionId' => $sessionId,
            'created_at' => now(),
            'updated_at' => now()
        ]);
        
        $stripeSecretKey = env('STRIPE_SECRET');
    \Stripe\Stripe::setApiKey($stripeSecretKey);

    // Retrieve the payment intent details
    $session = \Stripe\Checkout\Session::retrieve($sessionId);
    return response()->json($session);
    // Get the payment intent
    $paymentIntentId = $session->payment_intent;
    $paymentIntent = \Stripe\PaymentIntent::retrieve($paymentIntentId);
    
    // Check if the card is debit or credit
    $cardDetails = $paymentIntent->charges->data[0]->payment_method_details->card;
    $fundingType = $cardDetails->funding; 
     if ($fundingType !== 'debit') {
        return response()->json(['error' => 'Only debit card payments are accepted.'], 400);
    }

        // Return the Checkout session URL to the client
        return response()->json(['url' => $checkoutSession->url], 200);

    } catch (\Exception $e) {
        // Handle any errors that occur during the API request
        return response()->json(['error' => $e->getMessage()], 500);
    }
}

    public function depositStripeSuccess(Request $request)
    {
        $stripeSecretKey = env('STRIPE_SECRET');
    \Stripe\Stripe::setApiKey($stripeSecretKey);

    // Retrieve the payment intent details
    $sessionId = Session::get('stripe_session'); // Assuming you pass the session ID to this route
    // $session = \Stripe\Checkout\Session::retrieve($sessionId);
    
    // // Get the payment intent
    // $paymentIntentId = $session->payment_intent;
    // $paymentIntent = \Stripe\PaymentIntent::retrieve($paymentIntentId);
    
    // // Check if the card is debit or credit
    // $cardDetails = $paymentIntent->charges->data[0]->payment_method_details->card;
    // $fundingType = $cardDetails->funding; // 'credit' or 'debit'

    // Update the deposit record with the payment status
    DB::table('deposits')->where('id', $sessionId)->update([
        'status' => 'Paid', // Update status to Paid
        'updated_at' => now()
    ]);
        // Logic for successful deposit (e.g., notify the user, update records)
        return view('thank-you')->with('message', 'Your deposit was processed successfully. Thank you for your payment!'); // You can create a success.blade.php view to inform the user
    }

    public function depositStripeCancel()   
    {
        // Logic for cancelled deposit
        return view('deposit'); // You can create a cancel.blade.php view to inform the user
    }
    
    public function squareProcessDeposit(Request $request, $id)
    {
        // Get the JSON input and decode it
        $params = $request->json()->all();

        // Validate if 'amount', 'token', and 'payment_method' are provided
        if (empty($params['amount']) || empty($params['token']) || empty($params['payment_method'])) {
            return response()->json(['error' => 'Missing amount, token, or payment method'], 422);
        }

        try {
            // Prepare the request body
            $amount_money = [
                'amount' => (int)($params['amount'] * 100), // Convert to cents
                'currency' => 'USD' // Currency code
            ];

            // Get Square Access Token and Location ID from .env
            $accessToken = env('SQUARE_ACCESS_TOKEN'); // Your Square access token from .env
            $locationId = env('SQUARE_LOCATION_ID'); // Your Square location ID from .env

            // Build the payment request payload
            $body = [
                'source_id' => $params['token'], // Token generated from the frontend
                'amount_money' => $amount_money, // Amount details
                'location_id' => $locationId, // Square location ID
                'idempotency_key' => uniqid() // Unique key to prevent duplicate payments
            ];

            // Send the request to Square's API
            $response = Http::withToken($accessToken)
    ->post('https://connect.squareupsandbox.com/v2/payments', $body);

            // Check if the request was successful
            if ($response->successful()) {
            $deposit = DB::table('deposits')->insert([
    'status' => 'UnPaid',
    'payment_method' => 'Square',
    'amount' => $params['amount'],
    'username' => $params['username'],
    'server' => $params['server'],
    'created_at' => now(), // Ensure you set the timestamp if the table has a created_at column
    'updated_at' => now()  // Ensure you set the timestamp if the table has an updated_at column
]);
$depositId = $deposit->id;
                $paymentData = $response->json();

                // Check if the payment status is 'COMPLETED'
                if ($paymentData['payment']['status'] === 'COMPLETED') {
                    DB::table('deposits')->where('id', $depositId)->update([
                        'status' => 'paid' ]);
                    // Update the deposit status in the database
                   
                } else {
                    return response()->json(['error' => 'Payment not completed', 'status' => $paymentData['payment']['status']], 500);
                }
            } else {
                // Handle error from Square API
                return response()->json(['error' => 'Square API Error', 'details' => $response->json()], 500);
            }

        } catch (\Exception $e) {
            // Catch any other exceptions and return a failure response
            return response()->json(['error' => 'Exception', 'message' => $e->getMessage()], 500);
        }
    }
   public function showRegisterForm(Request $request)
{
   return view('register_deposit');
}
}
