<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;

class CheckbookController extends Controller
{
    // Show the form to edit the Checkbook keys
    public function index()
    {
        // Fetch the current values from the .env file
        $checkbookKey = env('CHECKBOOK_API_KEY');
        $checkbookSecret = env('CHECKBOOK_SECRET');

        return view('admin.checkbook-settings', compact('checkbookKey', 'checkbookSecret'));
    }

    // Update the Checkbook keys
    public function updateCheckbook(Request $request)
    {
        $request->validate([
            'checkbook_key' => 'required|string',
            'checkbook_secret' => 'required|string',
        ]);

        // Update the .env file with new keys
        $this->updateEnv([
            'CHECKBOOK_API_KEY' => $request->checkbook_key,
            'CHECKBOOK_SECRET' => $request->checkbook_secret,
        ]);

        // Refresh config to apply the changes
        Artisan::call('config:clear');

        return back()->with('success', 'Checkbook keys updated successfully!');
    }

    // Helper function to update .env
    protected function updateEnv(array $data)
    {
        $envPath = base_path('.env');

        if (File::exists($envPath)) {
            foreach ($data as $key => $value) {
                file_put_contents(
                    $envPath,
                    preg_replace(
                        "/^{$key}=.*/m",
                        "{$key}={$value}",
                        file_get_contents($envPath)
                    )
                );
            }
        }
    }
}