<?php
namespace App\Services;

class CheckbookService
{
    protected $apiKey;

    public function __construct()
    {
        $this->apiKey = env('CHECKBOOK_API_KEY'); // Store your API key in the .env file
    }

    public function createPayment($amount, $recipientEmail, $description)
    {
        $url = 'https://api.checkbook.io/v3/payments';
        $data = [
            'amount' => $amount,
            'currency' => 'USD',
            'recipient' => [
                'email' => $recipientEmail,
            ],
            'description' => $description,
        ];

        // Initialize cURL
        $ch = curl_init($url);

        // Set cURL options
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        // Execute cURL request
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        // Close cURL session
        curl_close($ch);

        // Handle the response
        if ($httpCode === 200) {
            print_r($response);
            exit;
        } else {
            print_r($response);
            exit;
        }
    }
}