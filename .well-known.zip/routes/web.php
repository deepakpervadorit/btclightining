<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DepositController;
use App\Http\Controllers\WithdrawalController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\DisputeController;
use App\Http\Controllers\ServiceProviderController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\StripeController;
use App\Http\Controllers\SquareController;
use App\Http\Controllers\CheckbookController;
use App\Http\Controllers\StripeWebhookController;
use App\Http\Controllers\CheckController;
use App\Http\Controllers\RolesController;
use App\Http\Controllers\PermissionsController;
use Illuminate\Support\Facades\Session;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

    Route::get('/deposit/register', [PaymentController::class, 'showRegisterForm'])
        ->name('show.Register.form');
// Deposit and Payment Form
    Route::get('/deposit/form', [PaymentController::class, 'showForm'])
        ->name('show.deposit.form');
    Route::get('/payments', [PaymentController::class, 'payments'])
        ->name('show.payments');
    Route::post('/webhook', 'PaymentController@handleWebhook')
        ->name('webhook');
    Route::post('/deposit/link', [PaymentController::class, 'depositLink'])
        ->name('deposit.link');
    Route::post('/process-deposit/s/{id}', [PaymentController::class, 'processDeposit'])
        ->name('process.deposit');
    Route::get('/deposit/s/success', [PaymentController::class, 'depositStripeSuccess'])
        ->name('deposit.stripe.success');

    Route::post('/stripe/webhook', [StripeWebhookController::class, 'handleWebhook']);
    Route::post('/process-deposit/sq/{id}', [PaymentController::class, 'squareProcessDeposit'])
        ->name('square.process.deposit');
        Route::post('/squareup_qr', [PaymentController::class, 'squareup_qr'])
        ->name('squareup_qr');

Route::get('/unauthorized', function () {
    return view('unauthorized');
})->name('unauthorized');
// Route::group(['middleware' => ['staffAuth:Superadmin']], function () {
//     // Route::group(['middleware' => ['permission:create_user']], function () {

//     // // Roles CRUD
//     // Route::resource('roles', RolesController::class);

//     // // Permissions CRUD
//     // Route::resource('permissions', PermissionsController::class);

//     Route::post('/send-check', [CheckController::class, 'sendCheck'])->name('check.send');
//     Route::get('/send-check', [CheckController::class, 'showForm'])->name('check.form');
//     // });

// });

// Route::post('/process-deposit/sq/{id}', [PaymentController::class, 'squareProcessDeposit'])->name('square.process.deposit');
// Roles CRUD
// Route::resource('roles', RolesController::class);

// Permissions CRUD
Route::resource('permissions', PermissionsController::class);

// Route::get('/deposit/form', [PaymentController::class, 'showForm'])->name('show.deposit.form');
// Route::get('/payments', [PaymentController::class, 'payments'])->name('show.payments');
// Route::post('/webhook', 'PaymentController@handleWebhook')->name('webhook');
// Route::post('/deposit/link', [PaymentController::class, 'depositLink'])->name('deposit.link');
// Route::post('/process-deposit/s/{id}', [PaymentController::class, 'processDeposit'])->name('process.deposit');
// Route::get('/deposit/s/success', [PaymentController::class, 'depositStripeSuccess'])->name('deposit.stripe.success');

// Route::post('/stripe/webhook', [StripeWebhookController::class, 'handleWebhook']);

Auth::routes();
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
});
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
Route::middleware(['staffAuth'])->group(function () {
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])
        ->name('dashboard')
        ->middleware('permission:Dashboard');

    // Deposit
    Route::get('/deposit', [DepositController::class, 'index'])
        ->name('deposit')
        ->middleware('permission:Deposit'); 
    Route::delete('/deposits/{id}', [DepositController::class, 'destroy'])
        ->name('deposits.destroy')
        ->middleware('permission:Deposit');

    // Withdrawal
    Route::get('/withdrawal', [WithdrawalController::class, 'index'])
        ->name('withdrawal')
        ->middleware('permission:Withdrawal');

    // Staff Management
    Route::resource('staff', StaffController::class)->middleware('permission:Staff');

    // Disputes
    Route::get('/disputes', [DisputeController::class, 'index'])
        ->name('disputes')
        ->middleware('permission:Disputes');

    // Service Provider
    Route::get('/service_provider', [ServiceProviderController::class, 'index'])
        ->name('service_provider')
        ->middleware('permission:Service Provider');
    Route::post('/games/add', [ServiceProviderController::class, 'addGame'])
        ->name('addgame')
        ->middleware('permission:Service Provider');
    Route::put('/games/update', [ServiceProviderController::class, 'updateGame'])
        ->name('updategame')
        ->middleware('permission:Service Provider');
    Route::delete('/games/delete/{id}', [ServiceProviderController::class, 'deleteGame'])
        ->name('deletegame')
        ->middleware('permission:Service Provider');

    // Stripe Settings
    Route::get('/stripe-settings', [StripeController::class, 'index'])
        ->name('admin.stripe.keys')
        ->middleware('permission:Stripe Setting');
    Route::post('/stripe-keys/update', [StripeController::class, 'updateStripe'])
        ->name('admin.stripe.keys.update')
        ->middleware('permission:Stripe Setting');

    // Square Settings
    Route::get('/square-settings', [SquareController::class, 'index'])
        ->name('admin.square.keys')
        ->middleware('permission:Square Settings');
    Route::post('/square-keys/update', [SquareController::class, 'updateSquare'])
        ->name('admin.square.keys.update')
        ->middleware('permission:Square Settings');

    // Checkbook Settings
    Route::get('/checkbook-settings', [CheckbookController::class, 'index'])
        ->name('admin.checkbook.keys')
        ->middleware('permission:Checkbook Settings');
    Route::post('/checkbook-keys/update', [CheckbookController::class, 'updateCheckbook'])
        ->name('admin.checkbook.keys.update')
        ->middleware('permission:Checkbook Settings');

    

    // Roles CRUD
    Route::resource('roles', RolesController::class)->middleware('permission:Roles and Permissions');
    Route::group(['middleware' => ['staffAuth:Superadmin']], function () {

        Route::post('/send-check', [CheckController::class, 'sendCheck'])->name('check.send')->middleware('permission:Roles and Permissions');
        Route::get('/send-check', [CheckController::class, 'showForm'])->name('check.form')->middleware('roles:Roles and Permissions');
        


    });
});