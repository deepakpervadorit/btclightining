<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DepositController;
use App\Http\Controllers\WithdrawalController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\DisputeController;
use App\Http\Controllers\ServiceProviderController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\StripeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/process-deposit/sq/{id}', [PaymentController::class, 'squareProcessDeposit'])->name('square.process.deposit');

Route::get('/deposit/form', [PaymentController::class, 'showForm'])->name('show.deposit.form');
Route::post('/deposit/link', [PaymentController::class, 'depositLink'])->name('deposit.link');
Route::post('/process-deposit/s/{id}', [PaymentController::class, 'processDeposit'])->name('process.deposit');
Route::get('/deposit/s/success', [PaymentController::class, 'depositStripeSuccess'])->name('deposit.stripe.success');

Auth::routes();
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
});
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
Route::middleware(['staffAuth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    Route::get('/deposit', [DepositController::class, 'index'])->name('deposit');
    Route::delete('/deposits/{id}', [DepositController::class, 'destroy'])->name('deposits.destroy');
    
    Route::get('/withdrawal', [WithdrawalController::class, 'index'])->name('withdrawal');
    
    Route::get('/staff', [StaffController::class, 'index'])->name('staff');
    Route::post('/staff/add', [StaffController::class, 'store'])->name('addstaff');
    Route::put('/staff/update', [StaffController::class, 'update'])->name('updatestaff');
    Route::delete('/staff/delete/{id}', [StaffController::class, 'destroy'])->name('deletestaff');
    
    
    Route::get('/disputes', [DisputeController::class, 'index'])->name('disputes');
    
    Route::get('/service_provider', [ServiceProviderController::class, 'index'])->name('service_provider');
    Route::post('/games/add', [ServiceProviderController::class, 'addGame'])->name('addgame');
    Route::put('/games/update', [ServiceProviderController::class, 'updateGame'])->name('updategame');
    Route::delete('/games/delete/{id}', [ServiceProviderController::class, 'deleteGame'])->name('deletegame');
    
    Route::get('/stripe-settings', [StripeController::class, 'index'])->name('admin.stripe.keys');
    Route::post('/stripe-keys/update', [StripeController::class, 'updateStripe'])->name('admin.stripe.keys.update');
});