<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
   public function showLoginForm()
    {
        return view('admin.login');
    }

    // Handle login via 'staff' table
    public function login(Request $request)
    {
        // Validate login credentials
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        // Retrieve the staff member using email
        $staff = DB::table('staff')
            ->where('email', $credentials['email'])
            ->first();

        // Check if the staff exists and the password matches
        if ($staff && Hash::check($credentials['password'], $staff->password)) {
            // Log the user in manually using session
            // Manually create the session since we're not using default user auth
            Session::put('staff_id', $staff->id);
            Session::put('staff_name', $staff->name);
            Session::put('staff_email', $staff->email);
            Session::put('staff_role', $staff->role);

            // Regenerate session to avoid session fixation
            $request->session()->regenerate();

            // Redirect to the dashboard or intended URL
            return redirect()->intended('/dashboard')->with('success', 'Logged in successfully.');
        }

        // If login failed, redirect back with an error message
        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->withInput();
    }

    // Handle logout
    public function logout(Request $request)
    {
        // Clear staff session
        Session::flush();

        // Regenerate session token
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        // Redirect to login page after logout
        return redirect()->route('login')->with('success', 'Logged out successfully.');
    }
}
