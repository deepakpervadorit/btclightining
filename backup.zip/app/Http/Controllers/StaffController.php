<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StaffController extends Controller
{
    public function index()
    {
        $staffs = DB::table('staff')->get();
        return view('admin.staff',compact('staffs'));
    }

 public function store(Request $request)
    {
        DB::table('staff')->insert([
            'name' => $request->name,
            'email' => $request->email,
            'role' => $request->role,
            'password' => bcrypt($request->password),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect()->back();
    }

    public function update(Request $request)
    {
        DB::table('staff')->where('id', $request->id)->update([
            'name' => $request->name,
            'email' => $request->email,
            'role' => $request->role,
            'updated_at' => now(),
        ]);

        return redirect()->back();
    }

    public function destroy($id)
    {
        DB::table('staff')->where('id', $id)->delete();

        return redirect()->back();
    }
}
