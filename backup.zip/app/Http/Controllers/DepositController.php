<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DepositController extends Controller
{
    public function index()
    {
        $deposits = DB::table('deposits')->get();
        return view('admin.deposit',compact('deposits'));
    }
    public function destroy($id)
{
    // Delete the deposit using DB::table()
    DB::table('deposits')->where('id', $id)->delete();

    // Redirect back with a success message
    return redirect()->route('deposit')->with('success', 'Deposit deleted successfully.');
}
}
