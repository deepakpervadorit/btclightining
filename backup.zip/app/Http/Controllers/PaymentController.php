<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe\Stripe;
use Stripe\Checkout\Session as CheckoutSession;
use Stripe\Price;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\Services\SquareService;

class PaymentController extends Controller
{
    public function showForm()
    {
        $games = DB::table('games')->get();
        return view('deposit',compact('games'));
    }

    public function depositLink(Request $request)
    {
        
        // echo "<pre>";
        // print_r($request->toArray());
        // exit;
        // Extract the inputs
        $server = $request->input('server');
        $paymentMethod = $request->input('payment_method');
        $username = $request->input('username');
        $amount = $request->input('amount');

        // Generate a unique
        $uniqueId = Str::random(10);
        // DB::table('deposits')->insert([
        //     'unique_id' => $uniqueId,
        //     'server' => $server,
        //     'payment_method' => $paymentMethod,
        //     'username' => $username,
        //     'amount' => $amount,
        //     'created_at' => now(),
        //     'updated_at' => now(),
        // ]);
        // Option 1: Redirect to the deposit link directly
        return view('deposit-link', compact('server', 'paymentMethod', 'username', 'amount', 'uniqueId'));
    }

    public function processDeposit(Request $request)
    {
        $stripeSecretKey = env('STRIPE_SECRET');
        Stripe::setApiKey($stripeSecretKey);

        // Get the amount from the request
        $amount = $request->input('amount');

        try {

            // Create a new Price object in Stripe for the specified amount
            $price = Price::create([
                'unit_amount' => $amount * 100, // Amount in cents
                'currency' => 'usd', // Set your desired currency
                'nickname' => 'Deposit Amount',
                'product_data' => [
                    'name' => 'Customer Deposit',
                ],
            ]);

            // Create a new Checkout session using the created Price ID
            $checkoutSession = CheckoutSession::create([
                'line_items' => [[
                    'price' => $price->id, // Use the created price ID
                    'quantity' => 1,
                ]],
                'mode' => 'payment', // Payment mode for one-time charges
                'success_url' => route('deposit.stripe.success'),
                'cancel_url' => route('show.deposit.form'),
            ]);

            // Return the Checkout session URL to the client
            return response()->json(['url' => $checkoutSession->url], 200);

        } catch (\Exception $e) {
            // Handle any errors that occur during the API request
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function depositStripeSuccess()
    {
        // Logic for successful deposit (e.g., notify the user, update records)
        return view('thank-you')->with('message', 'Your deposit was processed successfully. Thank you for your payment!'); // You can create a success.blade.php view to inform the user
    }

    public function depositStripeCancel()   
    {
        // Logic for cancelled deposit
        return view('deposit'); // You can create a cancel.blade.php view to inform the user
    }
    
    public function squareProcessDeposit(Request $request, $id)
    {
        // Get the JSON input and decode it
        $params = $request->json()->all();
    
        // Validate if 'amount', 'token', and 'payment_method' are provided
        if (empty($params['amount']) || empty($params['token']) || empty($params['payment_method'])) {
            return response()->json(['error' => 'Missing amount, token, or payment method'], 422);
        }
    
        try {
            // Process payment based on payment method
            switch ($params['payment_method']) {
                case 'card':
                    $result = SquareService::createPayment($params['token'], $params['amount'] * 100);
                    break;
                case 'cash-app':
                    $result = SquareService::createCashAppPayment($params['token'], $params['amount'] * 100);
                    break;
                case 'apple-pay':
                    $result = SquareService::createApplePayPayment($params['token'], $params['amount'] * 100);
                    break;
                default:
                    return response()->json(['error' => 'Invalid payment method'], 422);
            }
    
            // Check if payment status is completed
            if (isset($result->payment->status) && $result->payment->status === 'COMPLETED') {
                DB::table('deposits')->where('unique_id', $id)->update(['status' => 'Paid']);
                return response()->json(['success' => 'Payment data inserted successfully', 'res' => $result]);
            }
    
            return response()->json(['error' => 'Payment was not successful'], 500);
    
        } catch (\Exception $e) {
            // Catch any errors and return a failure response
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
