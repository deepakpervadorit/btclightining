<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Success</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<section class="bg-light">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-xl-5 col-lg-6 col-md-8 col-sm-10">
                <div class="card border-0 shadow">
                    <div class="card-body text-center">
                        <!-- Display the success message -->
                        <h3 class="fs-4">Thank You!</h3>
                        <?php if(session('message')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>
                        <a href="<?php echo e(url('/')); ?>" class="btn btn-warning">Go to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\360 projects\stripe-laravel\resources\views/thank-you.blade.php ENDPATH**/ ?>