@extends('layouts.app')

@section('content')
    <style>
        #loader {
            display: none;
        }
    </style>
    <section class="bg-light">
        <div class="container">
            <div class="row justify-content-center align-items-center min-vh-100">
                <div class="col-xl-5 col-lg-6 col-md-8 col-sm-10">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="alert alert-warning border-0 border-start border-5 border-warning rounded-0" role="alert">
                                <h3 class="fs-6">Your Deposit Link</h3>
                                @if($paymentMethod == 'stripe')
                                    <p>Click below on pay to complete your deposit:</p>
                                    <div class="d-flex mt-3">
                                        <form id="deposit-form" method="POST">
                                            @csrf
                                            <input type="hidden" name="server" value="{{ $server }}">
                                            <input type="hidden" name="paymentMethod" value="{{ $paymentMethod }}">
                                            <input type="hidden" name="username" value="{{ $username }}">
                                            <input type="hidden" name="amount" value="{{ $amount }}">
                                            <button type="submit" class="btn btn-warning btn-sm" id="checkout-button">Pay Now</button>
                                        </form>
                                        <a href="{{ route('show.deposit.form') }}" class="btn btn-light-warning btn-sm">New Deposit</a>
                                    </div>
                                @elseif($paymentMethod == 'squareup')
                                    <p>Click below on pay after select payment type to complete your deposit:</p>
                                    <form id="payment-form" method="POST">
                                        @csrf
                                        <input type="hidden" name="server" value="{{ $server }}">
                                        <input type="hidden" name="paymentMethod" value="{{ $paymentMethod }}">
                                        <input type="hidden" name="username" value="{{ $username }}">
                                        <input type="hidden" name="amount" id="amount" value="{{ $amount }}">
                                        <div class="mb-3 w-100" id="payment-type">
                                            <label class="form-label" for="payment-method">Payment Type</label>
                                            <select class="form-select" id="payment-method">
                                                <option value="card">Debit Card</option>
                                                <option value="cash-app">Cash App</option>
                                                <option value="apple-pay">Apple Pay</option>
                                            </select>
                                        </div>
                                        <div class="d-flex mb-3">
                                            <button type="submit" class="btn btn-warning btn-sm" id="payment-button">Pay Now</button>
                                            <a href="{{ route('show.deposit.form') }}" class="btn btn-light-warning btn-sm">New Deposit</a>
                                        </div>
                                    </form>
                                    
                                    <div id="loader" class="spinner-border text-primary" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <div id="card-container"></div>
                                    <button type="button" class="btn btn-warning btn-sm" id="card-button" style="display: none;">Pay</button>
                                    <div id="cash-app-pay"></div>
                                    <div id="apple-pay-button"></div>
                                    <div id="token-display"></div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://js.squareup.com/v2/paymentform"></script>
    <script src="https://web.squarecdn.com/v1/square.js"></script>

    <script>
        var base_url = "{{ url('/') }}";
        let card;
        async function get_data(amount, payment_method, token) {
            // Corrected fetch syntax
            const res = await fetch("{{ route('square.process.deposit', ['id' => $uniqueId]) }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                body: JSON.stringify({
                    amount: amount,
                    payment_method: payment_method,
                    token: token
                })
            });
            const data = await res.json();
            console.log(data);
            // if (data.res.payment.status === 'COMPLETED') {
            //     Swal.fire({
            //         title: " Successful !!",
            //         text: "The Payment Has been received !!",
            //         icon: "success"
            //     }).then((result) => {
            //         console.log(result);
            //         if (result.value) {
            //             window.location.href = base_url;
            //         }
            //     });
            // }
        }
  
        async function initializePayment(amount, payment_method) {
            try {
                document.getElementById('loader').style.display = 'block';
                document.getElementById('payment-button').style.display = 'none';
                document.getElementById('payment-type').style.display = 'none';
        
                const payments = Square.payments('sq0idp-gSL-VRx0LVQD7TU_9Of1oQ', 'LHBBJPXAFGQXM');
                const paymentRequest = payments.paymentRequest({
                    countryCode: 'US',
                    currencyCode: 'USD',
                    total: {
                        amount: amount.toFixed(2),
                        label: 'Total',
                    },
                });
        
                const options = {
                    redirectURL: window.location.href,
                    referenceId: 'my-distinct-reference-id',
                };
        
                if (payment_method === 'cash-app') {
                    const cashAppPay = await payments.cashAppPay(paymentRequest, options);
                    cashAppPay.addEventListener('ontokenization', (event) => {
                        const { tokenResult } = event.detail;
                        if (tokenResult.status === 'OK') {
                            console.log(`Payment token is ${tokenResult.token}`);
                            document.getElementById('token-display').innerHTML = `Payment token: ${tokenResult.token}`;
                            document.getElementById('token-display').style.display = 'block';
                            get_data(amount, payment_method, tokenResult.token);
                        } else {
                            console.error(tokenResult);
                        }
                    });
        
                    document.getElementById('cash-app-pay').style.display = 'block';
                    await cashAppPay.attach('#cash-app-pay', { shape: 'semiround', width: 'full' });
        
                } else if (payment_method === 'apple-pay') {
                    const applePay = await payments.applePay(paymentRequest, options);
                    applePay.addEventListener('ontokenization', (event) => {
                        const { tokenResult } = event.detail;
                        if (tokenResult.status === 'OK') {
                            console.log(`Payment token is ${tokenResult.token}`);
                            document.getElementById('token-display').innerHTML = `Payment token: ${tokenResult.token}`;
                            document.getElementById('token-display').style.display = 'block';
                            get_data(amount, payment_method, tokenResult.token);
                        } else {
                            console.error(tokenResult);
                        }
                    });
        
                    document.getElementById('apple-pay-button').style.display = 'block';
                    await applePay.attach('#apple-pay-button', { shape: 'semiround', width: 'full' });
                } else if (payment_method === 'card') {
                    
                    // Initialize Debit Card payment
                    card = await payments.card(); // Initialize card globally
                    await card.attach('#card-container'); // Attach the card input form to the container
    
                    document.getElementById('card-container').style.display = 'block';
                    document.getElementById('card-button').textContent = `Pay $${amount}`;
                    document.getElementById('card-button').style.display = 'block';
        
                    
                }
        
                document.getElementById('loader').style.display = 'none';
            } catch (error) {
                console.error('Error initializing payment:', error);
            }
        }
    
        document.getElementById('payment-form').addEventListener('submit', (event) => {
            event.preventDefault();
            const amount = parseFloat(document.getElementById('amount').value) + 0.09;
            const payment_method = document.getElementById('payment-method').value;
        
            initializePayment(amount, payment_method);
        });
        
        // After the card-button declaration in your existing code:
        document.getElementById('card-button').addEventListener('click', async (event) => {
            event.preventDefault(); // Prevent default button behavior
    
            const amount = parseFloat(document.getElementById('amount').value) + 0.09;
            const payment_method = 'card';
    
            try {
                if (!card) {
                    throw new Error('Card payment method not initialized'); // Ensure card is initialized
                }
    
                const result = await card.tokenize(); // Tokenize the card
                if (result.status === 'OK') {
                    console.log(`Payment token is ${result.token}`);
                    document.getElementById('token-display').innerHTML = `Payment token: ${result.token}`;
                    document.getElementById('token-display').style.display = 'block';
                    get_data(amount, payment_method, result.token); // Process the payment
                } else {
                    console.error(result.errors);
                }
            } catch (error) {
                console.error('Error during card payment:', error);
            }
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#deposit-form').on('submit', function(event) {
                event.preventDefault(); // Prevent the form from submitting normally
    
                // Serialize the form data
                var formData = $(this).serialize();
    
                // Perform AJAX request to process the deposit
                $.ajax({
                    url: "{{ route('process.deposit', ['id' => $uniqueId]) }}", // Laravel route for processing
                    method: 'POST',
                    data: formData, // Send serialized form data
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') // Ensure CSRF token is sent
                    },
                    success: function(response) {
                        console.log(response); // Debugging output
    
                        // Check if the response contains the URL for Stripe checkout
                        if (response.url) {
                            // Redirect to Stripe's checkout page
                            window.location.href = response.url;
                        } else {
                            alert('Failed to create Stripe session');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error); // Debugging output for errors
                        alert('There was an error processing the payment. Please try again.');
                    }
                });
            });
        });
    </script>
@endsection