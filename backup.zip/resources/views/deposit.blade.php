@extends('layouts.userapp')

@section('content')
    <section class="bg-light py-5">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-xl-5 col-lg-6 col-md-8 col-sm-10">
                    
                    @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif
                
                    @if($errors->any())
                        <div class="alert alert-danger">
                            @foreach ($errors->all() as $error)
                                {{ $error }}
                            @endforeach
                        </div>
                    @endif

                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="alert alert-info border-0 border-start border-5 border-info rounded-0" role="alert">
                                <h3 class="fs-6">Deposit</h3>
                                <p>Please fill out the form below to deposit to a server.</p>
                                <ol>
                                    <li>Select a server provider from the dropdown.</li>
                                    <li>Enter your username for the server provider.</li>
                                    <li>Enter the amount you would like to load.</li>
                                </ol>
                            </div>
                    
                            <div class="alert alert-warning border-0 border-start border-5 border-warning rounded-0" role="alert">
                                <h3 class="fs-6">Quick Payment Options</h3>
                                <p> 
                                    <img src="{{ asset('assets/img/apple-pay.svg') }}" height="35" class="me-1" alt="Apple Pay" />
                                    <img src="{{ asset('assets/img/cash-app.png') }}" height="40" class="me-1 py-2" alt="Cash App" />
                                    is supported through the Debit/Credit card option.
                                </p>
                            </div>
                            
                            <form method="post" class="p-3" action="{{ route('deposit.link') }}">
                                @csrf
                                <div class="mb-3">
                                    <label for="server" class="form-label">Server Provider</label>
                                    <select class="form-select" id="server" name="server">
                                        <option value="" selected disabled>Select a server provider</option>
                                        @foreach($games as $game)
                                            <option value="{{ $game->id }}">{{ $game->game }}</option>
                                        @endforeach
                                    </select>
                                </div>
                    
                                <div class="mb-3">
                                    <label for="payment-method" class="form-label">Payment Method</label>
                                    <select class="form-select" id="payment-method" name="payment_method">
                                        <option value="" selected disabled>Select a payment method</option>
                                        <option value="stripe">1 Cash App</option>
                                        <option value="squareup">2 Cash App</option>
                                    </select>
                                </div>
                    
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                            
                    
                                <div class="mb-3">
                                    <label for="amount" class="form-label">Amount</label>
                                    <input type="number" class="form-control" id="amount" name="amount" min="10" required>
                                </div>
                                
                                <div class="d-grid gap-2 mt-3">
                                    <button type="submit" class="btn btn-primary btn-lg">Deposit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection